<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: skyblue;
            padding: 20px;
        }
        .card {
            background-color: skyblue;
            border: 1px solid blue;
            border-radius: 8px;
            box-shadow: 0 4px 8px orange;
            margin-bottom: 20px;
        }
        .card-header, .card-body {
            padding: 20px;
        }
        .card-title {
            margin: 0;
            font-size: 30px;
            color: blue;
        }
        .card-body h2 {
            font-size: 28px;
            color: blue;
        }
        .card-body hr {
            background-color: orange;
            border: 2px solid orange;
            width: 25%;
        }
    </style>
</head>
<body>
    <div class="col-12">
        <div class="row my-5">
            <div class="col-md-12">
                <div class="card rounded-0 card-outline card-warning shadow">
                    <div class="card-body rounded-0">
                        <h2 class="text-center">About</h2>
                        <center><hr></center>
                        <div>
                            <?= file_get_contents("about_us.html") ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
