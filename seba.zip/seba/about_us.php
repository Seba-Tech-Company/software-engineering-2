<h3 class="text-center">Who We ARE:😊</h3>
<hr>
<div>
    <?php include("about_us.html") ?>
</div>