<style>
    #cover-img {
        background-color: skyblue;
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: center center;
    }
</style>

<h1> <?php echo $_settings->info('name') ?> </h1>
<hr class="border-info">
<div class="row">
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-primary elevation-1"><i class="fas fa-cogs"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Services</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `service_list` ")->num_rows;
                ?>
            </span>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-warning elevation-1"><i class="fas fa-user-friends"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Total Clients</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `client_list` ")->num_rows;
                ?>
            </span>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-secondary elevation-1"><i class="fas fa-clipboard-list"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Pending Designs</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `repair_list` where status = 0 ")->num_rows;
                ?>
            </span>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-success elevation-1"><i class="fas fa-vial"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Tested Designs</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `repair_list` where status = 1 ")->num_rows;
                ?>
            </span>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-primary elevation-1"><i class="fas fa-spinner"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Designs In-Progress</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `repair_list` where status = 2 ")->num_rows;
                ?>
            </span>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-warning elevation-1"><i class="fas fa-search"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Checking Designs</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `repair_list` where status = 3 ")->num_rows;
                ?>
            </span>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-success elevation-1"><i class="fas fa-check"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Complete Designs</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `repair_list` where status =4 ")->num_rows;
                ?>
            </span>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <div class="info-box bg-gradient-light shadow">
            <span class="info-box-icon bg-gradient-danger elevation-1"><i class="fas fa-times"></i></span>

            <div class="info-box-content">
            <span class="info-box-text">Cancelled Designs</span>
            <span class="info-box-number text-right">
                <?php 
                    echo $conn->query("SELECT * FROM `repair_list` where status =5 ")->num_rows;
                ?>
            </span>
            </div>
        </div>
    </div>
</div>
<hr>
<div class="w-100" style="height:50vh; background-color: skyblue;">
    <div id="cover-img" class="img-fluid h-100 bg-gradient-skyblue"></div>
</div>
