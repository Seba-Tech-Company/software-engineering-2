<?php require_once('./config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: skyblue;
            padding: 30px;
        }
        .card {
            background-color: skyblue;
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        .card-header {
            background-color: #007bff;
            color: white;
            border-radius: 10px 10px 0 0;
            padding: 30px;
        }
        .card-body {
            padding: 30px;
        }
        .card-title {
            margin: 0;
            font-size: 24px;
            color: orange;
        }
        .text-muted {
            color: #6c757d !important;
        }
        .form-control-border {
            border: 2px solid #007bff;
            border-radius: 5px;
        }
        .btn-primary {
            background-color: orange;
            border: none;
            border-radius: 25px;
            padding: 10px 30px;
        }
        .btn-primary:hover {
            background-color: green;
        }
        .rounded-pill {
            border-radius: 50px !important;
        }
        .footer-section {
            border-top: 1px solid #ddd;
            margin-top: 30px;
            padding-top: 30px;
        }
        .footer-section dt, .footer-section dd {
            display: inline-block;
            vertical-align: top;
        }
        .footer-section dt {
            width: 25%;
            font-weight: bold;
        }
        .footer-section dd {
            width: 70%;
            margin-left: 5%;
        }
    </style>
</head>
<body>
    <div class="col-12">
        <div class="row my-5 justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-body">
                        <h2 class="text-center">Get IN Touch</h2>
                        <center><hr class="bg-primary border-primary w-25 border-2"></center>
                        <?php if($_settings->chk_flashdata('pop_msg')): ?>
                            <div class="alert alert-success">
                                <i class="fa fa-check mr-2"></i> <?= $_settings->flashdata('pop_msg') ?>
                            </div>
                            <script>
                                $(function(){
                                    $('html, body').animate({scrollTop:0})
                                })
                            </script>
                        <?php endif; ?>
                        <form action="" id="message-form">
                            <input type="hidden" name="id">
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" class="form-control form-control-sm form-control-border" id="fullname" name="fullname" required placeholder="Boniface Nzuki">
                                    <small class="px-3 text-muted"> User Full Name</small>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" class="form-control form-control-sm form-control-border" id="contact" name="contact" required placeholder="xxxxxxxx">
                                    <small class="px-3 text-muted">Contact +254</small>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="email" class="form-control form-control-sm form-control-border" id="email" name="email" required placeholder="xxxxxx@xxxxxx.xxx">
                                    <small class="px-3 text-muted">Email @</small>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <small class="text-muted">Note</small>
                                    <textarea name="message" id="message" rows="4" class="form-control form-control-sm form-control-border" required placeholder="Write your message here"></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12 text-center">
                                    <button class="btn btn-primary rounded-pill col-5">Send Enquiry</button>
                                </div>
                            </div>
                        </form>
                        <div class="footer-section mt-5">
                            <h4 class="card-title">Link Information</h4>
                            <dl>
                                <dt class="text-muted mt-5 "><i class="fa fa-envelope"></i> Email @</dt>
                                <dd><?= $_settings->info('email') ?></dd>
                                <dt class="text-muted"><i class="fa fa-phone"></i> Contact +254</dt>
                                <dd><?= $_settings->info('contact') ?></dd>
                                <dt class="text-muted"><i class="fa fa-map-marked-alt"></i> Position</dt>
                                <dd><?= $_settings->info('address') ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(function(){
            $('#message-form').submit(function(e){
                e.preventDefault();
                var _this = $(this)
                $('.pop-msg').remove()
                var el = $('<div>')
                    el.addClass("pop-msg alert")
                    el.hide()
                start_loader();
                $.ajax({
                    url:_base_url_+"classes/Master.php?f=save_message",
                    data: new FormData($(this)[0]),
                    cache: false,
                    contentType: false,
                    processData: false,
                    method: 'POST',
                    type: 'POST',
                    dataType: 'json',
                    error:err=>{
                        console.log(err)
                        alert_toast("An error occurred",'error');
                        end_loader();
                    },
                    success:function(resp){
                        if(resp.status == 'success'){
                            location.reload();
                        }else if(!!resp.msg){
                            el.addClass("alert-danger")
                            el.text(resp.msg)
                            _this.prepend(el)
                        }else{
                            el.addClass("alert-danger")
                            el.text("An error occurred due to unknown reason.")
                            _this.prepend(el)
                        }
                        el.show('slow')
                        $('html, body').animate({scrollTop:0},'fast')
                        end_loader();
                    }
                })
            })
        })
    </script>
</body>
</html>
