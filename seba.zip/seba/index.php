<?php require_once('./config.php'); ?>
<!DOCTYPE html>
<html lang="en" style="height: auto;">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Seba Tech Company</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            padding: 20px;
        }
        #header {
            height: 90vh;
            width: 120%;
            position: relative;
            top: -3em;
            background: url(<?= validate_image($_settings->info("cover")) ?>) center center / cover no-repeat;
            display: flex;
            align-items: center;
            justify-content: center;
            color: blue;
            text-align: center;
        }
        #header h1 {
            font-size: 3em;
            background: orange;
            padding: 10px;
            border-radius: 10px;
        }
        #top-Nav a.nav-link.active {
            color: blue;
            font-weight: 900;
            position: relative;
        }
        #top-Nav a.nav-link.active:before {
            content: "";
            position: absolute;
            border-bottom: 2px solid orange;
            width: 33.33%;
            left: 33.33%;
            bottom: 0;
        }
        .content-wrapper {
            padding-top: 50px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 8px skyblue;
        }
        .card-header {
            background-color: blue;
            color: white;
            border-radius: 15px 15px 0 0;
            padding: 20px;
        }
        .card-body {
            padding: 20px;
        }
        .modal-content {
            border-radius: 15px;
        }
        .btn-primary {
            background-color: blue;
            border: none;
        }
        .btn-secondary {
            background-color: orange;
            border: none;
        }
        .modal-header {
            border-bottom: none;
        }
        .modal-footer {
            border-top: none;
        }
        .btn-close {
            background: none;
            border: none;
            font-size: 1.5em;
        }
    </style>
</head>
<?php require_once('inc/header.php') ?>
<body class="layout-top-nav layout-fixed layout-navbar-fixed" style="height: auto;">
    <div class="wrapper">
        <?php $page = isset($_GET['page']) ? $_GET['page'] : 'home'; ?>
        <?php require_once('inc/topBarNav.php') ?>
        <?php if($_settings->chk_flashdata('success')): ?>
        <script>
            alert_toast("<?php echo $_settings->flashdata('success') ?>", 'success')
        </script>
        <?php endif; ?>
        <div class="content-wrapper">
            <?php if($page == "home" || $page == "about_us"): ?>
            <div id="header">
                <h1 class="site-title"><?php echo $_settings->info('name') ?></h1>
            </div>
            <?php endif; ?>
            <section class="content">
                <div class="container">
                    <?php 
                    if (!file_exists($page.".php") && !is_dir($page)) {
                        include '404.html';
                    } else {
                        if (is_dir($page))
                            include $page.'/index.php';
                        else
                            include $page.'.php';
                    }
                    ?>
                </div>
            </section>
            <div class="modal fade" id="confirm_modal" role="dialog">
                <div class="modal-dialog modal-md modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Confirmation</h5>
                        </div>
                        <div class="modal-body">
                            <div id="delete_content"></div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-warning" id="confirm" onclick="">Continue</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="uni_modal" role="dialog">
                <div class="modal-dialog modal-md modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"></h5>
                        </div>
                        <div class="modal-body"></div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary" id="submit" onclick="$('#uni_modal form').submit()">Save</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="uni_modal_right" role="dialog">
                <div class="modal-dialog modal-full-height modal-md" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span class="fa fa-arrow-right"></span>
                            </button>
                        </div>
                        <div class="modal-body"></div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="viewer_modal" role="dialog">
                <div class="modal-dialog modal-md" role="document">
                    <div class="modal-content">
                        <button type="button" class="btn-close" data-dismiss="modal"><span class="fa fa-times"></span></button>
                        <img src="" alt="">
                    </div>
                </div>
            </div>
        </div>
        <?php require_once('inc/footer.php') ?>
    </div>
</body>
</html>
